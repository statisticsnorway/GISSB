library(testthat)
library(GISSB)

test_check("GISSB")
