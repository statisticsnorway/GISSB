

testthat::test_that("Tester adresse_api_koord", {
  adresse_api_koord(postnummer = "0177", adresse = "Akersveien 26")
})

